$(document).bind("mobileinit", function(){
  $.extend(  $.mobile , {
    allowCrossDomainPages: true
  });
});